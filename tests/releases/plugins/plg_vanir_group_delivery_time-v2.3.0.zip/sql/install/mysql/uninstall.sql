SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS `#__redshopb_delivery_time_group`;

SET FOREIGN_KEY_CHECKS = 1;
