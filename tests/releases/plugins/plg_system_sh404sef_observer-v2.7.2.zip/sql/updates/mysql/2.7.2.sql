ALTER TABLE `#__sh404sef_observer`
	CHANGE `data` `data` LONGTEXT NOT NULL;