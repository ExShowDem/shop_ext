CREATE TABLE IF NOT EXISTS `#__sh404sef_observer`
(
	`id`     INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
	`data`   TEXT             NOT NULL,
	PRIMARY KEY (`id`)
) ENGINE = InnoDB;