SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS `#__redshopb_shipping_route`;
DROP TABLE IF EXISTS `#__redshopb_shipping_route_address_xref`;

SET FOREIGN_KEY_CHECKS = 1;
