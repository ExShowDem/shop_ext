UPDATE `#__redshopb_sync` SET
 `hash_key` = ''
 WHERE
 `reference` = 'erp.webservice.field_values'
;