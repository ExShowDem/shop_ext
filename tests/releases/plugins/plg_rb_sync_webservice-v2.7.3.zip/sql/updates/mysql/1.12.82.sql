UPDATE `#__redshopb_sync` SET `main_reference` = 1 where `reference` = 'erp.webservice.categories';
