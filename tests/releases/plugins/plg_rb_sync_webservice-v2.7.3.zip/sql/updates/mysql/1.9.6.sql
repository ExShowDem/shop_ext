UPDATE `#__redshopb_sync` SET
 `serialize` = '',  `hash_key` = ''
 WHERE `reference` = 'erp.webservice.product_images';
