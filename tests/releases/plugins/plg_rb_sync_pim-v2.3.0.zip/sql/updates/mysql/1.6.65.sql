INSERT INTO `#__redshopb_field` (`scope`, `type_id`, `name`, `alias`, `title`, `description`, `ordering`, `state`, `searchable_frontend`, `searchable_backend`, `multiple_values`, `filter_type_id`) VALUES
  ('product', 12, 'Instructions', 'product-instructions', 'Product Instructions', 'Product Instruction document files', 6, 1, 1, 1, 1, 1),
  ('product', 12, 'Securitysheet', 'product-securitysheet', 'Product Security sheets', 'Product Security sheet document files', 7, 1, 1, 1, 1, 1),
  ('product', 13, 'Video', 'product-video', 'Product videos', 'Product video files', 8, 1, 1, 1, 1, 1)
;