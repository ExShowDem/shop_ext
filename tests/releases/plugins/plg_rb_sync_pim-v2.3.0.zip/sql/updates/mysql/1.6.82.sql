DELETE FROM `#__redshopb_sync` WHERE `reference` = 'erp.pim.field' AND `remote_key` = 'DimensionMmCVL';
