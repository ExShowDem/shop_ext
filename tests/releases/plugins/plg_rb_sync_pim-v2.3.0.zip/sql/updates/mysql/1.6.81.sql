UPDATE `#__redshopb_field` SET `name` = 'DJItemNo', `alias` = 'product-djitemno' WHERE `name` = 'ProductDJItemNo';
