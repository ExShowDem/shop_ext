UPDATE `#__redshopb_cron` SET `offset_time` = '+4 hour' WHERE `plugin` = 'pim' AND `offset_time` = '+1 hour';
