SET FOREIGN_KEY_CHECKS = 0;

DELETE FROM `#__redshopb_cron` WHERE `id` IN (
1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 16, 17, 18, 19, 20, 24, 26, 32, 33, 34, 35, 38, 39, 40, 41, 42, 43
);

SET FOREIGN_KEY_CHECKS = 1;
