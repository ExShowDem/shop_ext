SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS `#__redshopb_stockroom_group_stockroom_xref`;
DROP TABLE IF EXISTS `#__redshopb_stockroom_group`;

SET FOREIGN_KEY_CHECKS = 1;
